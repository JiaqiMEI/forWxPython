
This sample is an example of using wxPython from within a wxWidgets C++
application that embeds Python. Most things you'll need to know are documented
in the source code in embedded.cpp. 