/**********************************************************************
 * Premake - gnu.h
 * The GNU makefile target
 *
 * Copyright (c) 2002-2005 Jason Perkins and the Premake project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License in the file LICENSE.txt for details.
 **********************************************************************/

#define DOT_MAKE   "make"

int gnu_generate();

int gnu_cpp();
int gnu_cs();

/* Helpers */
int gnu_pkgOwnsPath();
const char* gnu_escapePath(const char* path);
