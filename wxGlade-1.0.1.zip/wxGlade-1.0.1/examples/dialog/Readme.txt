This example shows how to use a dialog.
On button press or menu selection it will be instantiated, filled with data, shown modally
and if the user presses OK, the entered value will be read back.
