wxGlade Examples:

AllWidgets:  examples showing most of the supported controls for wxPython 2.8 and >=3.0

dialog:      use a dialog created with wxGlade

html:        use wx.html.HtmlWindow to display simple HTML pages
html2:       use wx.html2.WebView to display HTML with Javascript and CSS
             (not available on wxPython 2.8)

lib_plot:    use wx.lib.plot.PlotCanvas for plotting
matplotlib:  use a Matplotlib canvas for plotting, quick and dirty version
matplotlib2: use a Matplotlib canvas for plotting, better structured
matplotlib3: full Matplotlib embedding example

SpeedMeter:  demonstrate wx.lib.agw.speedmeter.SpeedMeter

py_shell:    show how to embed a Python shell wx.py.shell.Shells
